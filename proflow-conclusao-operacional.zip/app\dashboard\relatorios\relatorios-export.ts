import { formatDateBR, formatDateTimeBR, formatNumberBR } from "@/lib/br-formatters";
import { toBrazilianCsv } from "@/lib/csv-br";
import type { ReportDataset } from "./relatorios-types";
export function reportCsv(dataset: ReportDataset) {
  const rows: unknown[][] = [
    ["Relatório ProFlow"],
    ["Gerado em", formatDateTimeBR(dataset.generatedAt)],
    ["Período", `${formatDateBR(dataset.period.start)} a ${formatDateBR(dataset.period.end)}`],
    ["Área", dataset.filters.area],
    [],
    ["Fontes"],
    ["Fonte", "Disponível", "Parcial", "Registros", "Atualização", "Avisos"],
  ];
  for (const status of dataset.sourceStatus)
    rows.push([
      status.source,
      status.available ? "Sim" : "Não",
      status.partial ? "Sim" : "Não",
      status.recordCount,
      status.updatedAt ? formatDateTimeBR(status.updatedAt) : "",
      status.warnings.join(" | ") || status.error || "",
    ]);
  for (const section of dataset.sections) {
    rows.push(
      [],
      [section.title],
      ["Indicador", "Valor", "Valor anterior", "Variação (%)", "Status", "Descrição"],
    );
    for (const item of section.metrics)
      rows.push([
        item.title,
        item.formattedValue,
        item.previousValue ?? "",
        item.percentageChange === undefined ? "Sem base comparável" : `${formatNumberBR(item.percentageChange, 2)}%`,
        item.status,
        item.description,
      ]);
    for (const ranking of section.rankings) {
      rows.push([], [ranking.title], ["Posição", "Item", "Valor"]);
      ranking.items.forEach((item, index) =>
        rows.push([index + 1, item.label, item.formattedValue]),
      );
    }
  }
  if (dataset.cashProjection?.available) {
    rows.push(
      [],
      ["Projeção financeira"],
      ["Período", "Entradas previstas", "Saídas previstas", "Saldo projetado"],
    );
    for (const window of dataset.cashProjection.windows)
      rows.push([
        `Próximos ${window.days} dias`,
        formatNumberBR(window.incomeCents / 100, 2),
        formatNumberBR(window.expenseCents / 100, 2),
        formatNumberBR(window.balanceCents / 100, 2),
      ]);
    rows.push(
      ["Vencido a receber", formatNumberBR(dataset.cashProjection.overdueIncomeCents / 100, 2)],
      ["Vencido a pagar", formatNumberBR(dataset.cashProjection.overdueExpenseCents / 100, 2)],
    );
  }
  return toBrazilianCsv(rows);
}
export function downloadReportCsv(dataset: ReportDataset) {
  if (
    !dataset.sections.some((section) =>
      section.metrics.some((metric) => metric.value !== undefined),
    )
  )
    throw new Error("Não há dados filtrados para exportar.");
  const blob = new Blob([reportCsv(dataset)], { type: "text/csv;charset=utf-8" }),
    url = URL.createObjectURL(blob),
    link = document.createElement("a"),
    date = dataset.generatedAt.slice(0, 10),
    area = dataset.filters.area.toLowerCase();
  link.href = url;
  link.download = `relatorio-${area}-${dataset.period.start}-a-${dataset.period.end}-${date}.csv`;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}
